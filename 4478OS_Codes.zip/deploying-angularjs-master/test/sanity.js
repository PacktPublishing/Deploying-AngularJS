'use strict';

describe('Sanity', function () {
  it('should work properly', function () {
    true.should.equal(true);
  });
});
